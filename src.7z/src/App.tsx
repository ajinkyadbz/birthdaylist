import React, { Component } from 'react';
import './App.css';
import {USER_DATA} from './Constants';


import  AddList  from './components/addList.js';
import  List from './components/List.js';
import { addItem } from './actions/actions';


interface initialState {
  dispatch: any,
  visibleTodos: any
}

export class App extends Component<initialState> {
  constructor(props:initialState){
    super(props);
  }
  
    render(){
      const { dispatch, visibleTodos } = this.props
    return (
      <div className="App">
              <AddList onAddClick = {(text:any) => dispatch(addItem(text))} />
              <List contents={visibleTodos} />
      </div>
    );
    }
  }

export default App;
