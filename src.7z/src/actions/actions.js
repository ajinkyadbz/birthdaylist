export const ADD_LIST = 'ADD_LIST'

let nextItem = 0;

export function addItem(text){
    return {
        type: ADD_LIST,
        id: nextItem++,
        text
    };
}