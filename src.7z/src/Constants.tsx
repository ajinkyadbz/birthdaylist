export const USER_DATA =[
    {
        "name" : "Ajinkya "
    },
    {
        "name" : "Datalkar"
    }
]