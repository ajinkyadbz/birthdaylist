import { combineReducers } from "redux";
import {ADD_LIST} from '../actions/actions.js'

function add_item(state,action){
    switch(action.type){
        case ADD_LIST:
            return{
                id: action.id,
                text: action.text
            }
        default:
            return state
    }
}

function lists(state = [],action){
    switch(action.type){
        case ADD_LIST:
            return [
                ...state,
                add_item(undefined,action)
            ]
        default:
            return state
    }

}

const listStore = combineReducers({
    lists
})
export default listStore